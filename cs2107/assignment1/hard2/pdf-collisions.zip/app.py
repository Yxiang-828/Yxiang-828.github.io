from flask import Flask, request, render_template_string
import hashlib
import os
import tempfile
import sys
import contextlib
from diff_pdf_visually import pdf_similar

app = Flask(__name__)

MASTER_PDF = "Assignment 1.pdf"

with open(MASTER_PDF, "rb") as f:
    MASTER_BYTES = f.read()
MASTER_HASH = hashlib.md5(MASTER_BYTES).hexdigest()

FLAG = "CS2107{FAKE_FLAG}"

UPLOAD_FORM = """
<!DOCTYPE html>
<html>
  <head><title>PDF Upload</title></head>
  <body>
    <h1>Upload your PDF</h1>
    <form method="POST" enctype="multipart/form-data">
      <div style="display: flex; flex-direction: column; gap: 10px;">
        <input type="file" name="pdf1" accept="application/pdf" required>
        <input type="file" name="pdf2" accept="application/pdf" required>
      </div>
      <input style="margin-top: 10px;" type="submit" value="Upload">
    </form>
    {% if result %}
      <p>{{ result }}</p>
    {% endif %}
  </body>
</html>
"""


@contextlib.contextmanager
def suppress_output():
    with open(os.devnull, "w") as devnull:
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = devnull, devnull
        try:
            yield
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "pdf1" not in request.files or "pdf2" not in request.files:
            return render_template_string(UPLOAD_FORM, result="Please upload 2 files!")
        file1 = request.files["pdf1"]
        file2 = request.files["pdf2"]

        if file1.filename == "" or file2.filename == "":
            return render_template_string(UPLOAD_FORM, result="No selected file.")

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            file1.save(tmp.name)
            upload_path1 = tmp.name

        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            file2.save(tmp.name)
            upload_path2 = tmp.name

        try:
            with suppress_output():
                similarity_result1 = pdf_similar(MASTER_PDF, upload_path1)
                similarity_result2 = pdf_similar(MASTER_PDF, upload_path2)

            with open(upload_path1, "rb") as f:
                upload_bytes1 = f.read()
            with open(upload_path2, "rb") as f:
                upload_bytes2 = f.read()

            upload_hash1 = hashlib.md5(upload_bytes1).hexdigest()
            upload_hash2 = hashlib.md5(upload_bytes2).hexdigest()

            if len(set([MASTER_BYTES, upload_bytes1, upload_bytes2])) != 3:
                result = "Did you just try submitting the same file????"
            elif (
                similarity_result1
                and similarity_result2
                and len(set([MASTER_HASH, upload_hash1, upload_hash2])) < 3
            ):
                result = f"Flag: {FLAG}"
            else:
                result = "No flag for you. Try again!"
        except Exception:
            result = "Error :( Did you submit a non-PDF by accident?"
        finally:
            os.remove(upload_path1)
            os.remove(upload_path2)

        return render_template_string(UPLOAD_FORM, result=result)

    return render_template_string(UPLOAD_FORM, result=None)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
